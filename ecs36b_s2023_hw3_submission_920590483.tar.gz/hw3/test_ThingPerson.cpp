
// test_GPS.cpp

#include "Person.h"
#include "Thing.h"
#include "Record.h"

int
main(int argc, char *argv[])
{
  // if (argc != 3) return -1;

// latitude and longitude of each location
  GPS_DD gps_Everson { 38.538703, -121.750230, "Everson 176" };
  GPS_DD gps_Silo  { 38.539141, -121.753208, "Silo Station" };
  GPS_DD gps_MooreAndPollock { 38.564365, -121.719229, "Moore and Pallock"};
  GPS_DD gps_8thandJ { 38.552037, -121.738759, "8th and J Street"};

// identifies them each as people
  Person Instructor {"Android Device", "Instructor", "Instructor", gps_Everson};
  Person John { "Computer", "John", "Student", gps_Everson};
  Person Tiffany { "Bus", "Tiffany", "Bus Driver", gps_Everson};

//allows us to get instructor's item
  Thing items1 { Instructor };
  items1.model = "Android Device";
  items1.location = gps_Everson;

//allows us to get John's item
  Thing items2 { John };
  items2.model = "Computer";
  items2.location = gps_Everson;

//allows us to get Tiffany's item
  Thing items3 { Tiffany };
  items3.model = "Bus";
  items3.location = gps_Everson;




  Json::Value x;
  x = gps_Everson.dump2JSON();
  //std::cout << x.toStyledString() << std::endl;


// INSTRUCTOR LEFT EVERSON AT 6:00PM
JvTime everson_time{"2023-04-12T18:00:00+0000"};
  Record r1 {Instructor, items1, gps_Everson, everson_time, "location1"};
  x = r1.dump2JSON();
  std::cout << x.toStyledString() << std::endl;




  
// INSTRUCTOR, TIFFANY, AND JOHN LEFT SILO AT 6:10PM
JvTime silo_time{"2023-04-12T18:10:00+0000"};

  Record r2 {John, items2, gps_Silo, silo_time ,"location2"};
  x = r2.dump2JSON();
  std::cout << x.toStyledString() << std::endl;
  

  Record r3 {Instructor, items1, gps_Silo, silo_time, "location2"};
  x = r3.dump2JSON();
  std::cout << x.toStyledString() << std::endl;



  Record r4 {Tiffany, items3, gps_Silo, silo_time, "location2"};
  x = r4.dump2JSON();
  std::cout << x.toStyledString() << std::endl;


 



  
// JOHN LEFT THE BUS AT 8TH AND J STREET AT 6:20PM. INSTRUCTOR, JOHN, AND TIFFANY WERE ALL THERE!
JvTime JStreet_time{"2023-04-12T18:20:00+0000"};

  Record r5 {John, items2, gps_8thandJ, JStreet_time, "location3"};
  x = r5.dump2JSON();
  std::cout << x.toStyledString() << std::endl;

  Record r6 {Tiffany, items3, gps_8thandJ, JStreet_time, "location3"};
  x = r6.dump2JSON();
  std::cout << x.toStyledString() << std::endl;

  Record r7 {Instructor, items1, gps_8thandJ, JStreet_time, "location3"};
  x = r7.dump2JSON();
  std::cout << x.toStyledString() << std::endl;

  



 
JvTime MooreAndPollock_time{"2023-04-12T18:32:00+0000"};


  Record r8 {Tiffany, items3, gps_MooreAndPollock, MooreAndPollock_time, "location4"};
  x = r8.dump2JSON();
  std::cout << x.toStyledString() << std::endl;


  Record r9 {Instructor, items1, gps_MooreAndPollock, MooreAndPollock_time, "location4"};
  x = r9.dump2JSON();
  std::cout << x.toStyledString() << std::endl;

  return 0;
}

