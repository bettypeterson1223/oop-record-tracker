Deepa Bhat (920720185) and Betty Peterson (920590483)

This program allows for the object, location, time, and coordinates of a certain person (Instructor, John, or Tiffany) to be triangulated
1. The makefile within this program compiles the different programs.
2. Into the terminal, type "make," to compile the program, and ./test_ThingPerson in order to run it.