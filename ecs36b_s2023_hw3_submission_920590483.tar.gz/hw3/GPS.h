
#ifndef _GPS_H_
#define _GPS_H_

// GPS.h

#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <cstdlib>


#include "ecs36b_Common.h"
#include "JvTime.h"
using namespace std;

class GPS_DD
{
 private:
  double latitude;
  double longitude;
  std::string name;
 public:
  explicit GPS_DD();
  explicit GPS_DD(double, double, std::string);
  double getLatitude();
  double getLongitude();
  std::string getName();
  double distance(GPS_DD);
  Json::Value dump2JSON();
};

#endif /* _GPS_H_ */
