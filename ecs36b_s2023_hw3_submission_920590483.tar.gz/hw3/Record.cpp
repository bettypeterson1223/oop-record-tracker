
#include "Record.h"

Record::Record(Person _p, Thing _t, GPS_DD _g, JvTime _jt, std::string _locationOfEvents)
{
  this->who = _p;
  this->what = _t;
  this->where = _g;
  this->when = _jt;
  this->locations_name = _locationOfEvents;
}

Record::Record()
{
  this->locations_name = "";
}

void
Record::setWho(Person _p)
{
  this->who = _p;
}

void
Record::setWhat(Thing _t)
{
  this->what = _t;
}

void
Record::setWhere(GPS_DD _g)
{
  this->where = _g;
}

void
Record::setWhen(JvTime _jt)
{
  this->when = _jt;
}



Json::Value
Record::dump2JSON()
{
  Json::Value result;
  if (this->locations_name == "location1"){
    printf("Location 1: Everson Hall 176 \n");
  }
  if (this->locations_name == "location2"){
    printf("Location 2: Silo Station \n");
  }
  if (this->locations_name == "location3"){
    printf("Location 3: 8th and J Street \n");
  }
  if (this->locations_name == "location4"){
    printf("Location 4: Moore and Pollock \n");
  }
  result["who"] = (this->who).dump2JSON();
  result["what"] = (this->what).dump2JSON();
  result["where"] = (this->where).dump2JSON();
  result["when"] = (this->when).dump2JSON();
  return result;
}
