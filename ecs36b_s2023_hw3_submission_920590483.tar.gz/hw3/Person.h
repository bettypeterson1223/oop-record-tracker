
#ifndef _PERSON_H_
#define _PERSON_H_

// Person.h

#include "GPS.h"
#include "JvTime.h"

class Person
{
 private:
  std::string objects;
  std::string name;
  std::string occupation;
  GPS_DD home;
  GPS_DD location;
  JvTime since_when;
  
public:
  Person(std::string, std::string, std::string, GPS_DD);
  Person();
  void setHome(GPS_DD);
  void setLocation(GPS_DD, JvTime);

  bool operator==(Person& aPerson);
  std::string getObjects();
  std::string getName();
  std::string getOccupation();
  GPS_DD getHome();
  GPS_DD getLocation();
  JvTime getLocationTime();
  void dump();
  Json::Value dump2JSON();
};

#endif  /* _PERSON_H_ */
