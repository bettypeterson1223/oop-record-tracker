
#include "Person.h"

Person::Person(std::string arg_objects, std::string arg_name, std::string arg_occupation, GPS_DD arg_home)
{
  this->objects = arg_objects;
  this->name = arg_name;
  this->home = arg_home;
  this->occupation = arg_occupation;
}

Person::Person()
{
  this->objects = "";
  this->name = "";
  this->occupation = "";
  this->home = GPS_DD {};
}

void
Person::setHome
(GPS_DD arg_home)
{
  this->home = arg_home;
}

void
Person::setLocation
(GPS_DD arg_location, JvTime arg_time)
{
  this->location = arg_location;
  this->since_when = arg_time;
}

GPS_DD
Person::getHome
(void)
{
  return this->home;
}

std::string
Person::getObjects()
{
  return this->objects;
}

std::string
Person::getName()
{
  return this->name;
}

std::string
Person::getOccupation()
{
  return this->occupation;
}

// function prototype
bool
Person::operator==
(Person& aPerson)
{
  return (this->objects == aPerson.getObjects());

  return (this->name == aPerson.getName());

  return (this ->occupation == aPerson.getOccupation());
  
  return ((this->name == aPerson.getName()) &&
	  (this->objects == aPerson.getObjects()) &&
    (this->occupation == aPerson.getOccupation()));
}

void Person::dump
(void)
{
  std::cout << "[Person] dump-begin" << std::endl;
  std::cout << "object         = " << this->objects << std::endl;
  std::cout << "name           = " << this->name << std::endl;
  std::cout << "occupation     = " << this->occupation << std::endl;
  std::cout << "[Person] dump-end \n" << std::endl;

  return;
}

Json::Value
Person::dump2JSON()
{
  Json::Value result;
  //std::string name = this->getName();
  result["job"] = (occupation);
  result["name"] = (name);

  return result;

}


